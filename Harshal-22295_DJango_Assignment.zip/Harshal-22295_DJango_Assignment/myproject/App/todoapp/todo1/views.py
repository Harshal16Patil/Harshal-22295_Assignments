from django.shortcuts import render ,redirect
from django.http import HttpResponse
from django.http import HttpResponseRedirect

from .models import *
from .forms import *


# Create your views here.
def index(request):
    todo = todo1.objects.all()
    form= todoform()

    if request.method == 'POST':
        form=todoform(request.POST)
        if form.is_valid():
            form.save()
        return redirect('/')

    context={'todo':todo, 'form':form}
    return render(request, 'todo1/list.html',context)

def updateList(request, pk):
    todo =todo1.objects.get(id=pk)
    form=todoform(instance=todo)
    
    if request.method=='POST':
        form= todoform(request.POST,instance=todo)
        if form.is_valid():
            form.save()
            return redirect('/')

    context={'form':form}

    return render(request,'todo1/update_task.html',context)

def deleteTask(request, pk):
    item =todo1.objects.get(id=pk)
    
    if request.method =="POST":
        item.delete()
        return redirect('/')
    context={'item':item}
    return render(request,'todo1/delete.html',context)