import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent { 
  title!: 'Question2';
   exform!: FormGroup;
  ngOnInit() {
    this.exform=new FormGroup({
      'name': new FormControl('Enter Name',Validators.required),
      'email': new FormControl('Enter Email',[Validators.required,Validators.email]),
      'mobile-number': new FormControl(
        'Enter Number',
        [Validators.required,
          Validators.pattern('')
        ]
        ),
    });
    
  }
}
