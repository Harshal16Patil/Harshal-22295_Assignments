import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registerform',
  templateUrl: './registerform.component.html',
  styleUrls: ['./registerform.component.css']
})
export class RegisterformComponent implements OnInit {

  constructor() { }
  registerform:any; ////form Name

  ngOnInit(): void {
    this.registerform=new FormGroup({
      'firstname':new FormControl(null,[Validators.required,Validators.pattern('[a-zA-Z]*')]),
      'lastname':new FormControl(null,[Validators.required,Validators.pattern('[a-zA-Z]*')]),
      'email':new FormControl(null,[Validators.required,Validators.email]),
      'mobileNumber':new FormControl(null,[Validators.required,Validators.pattern('[0-9]*'),Validators.minLength(10),Validators.maxLength(10)]),
      'address':new FormControl(null,Validators.required),
      'date':new FormControl(null,Validators.required),
    });
  }
  //submit function
  SubmitData()
  {
    console.log(this.registerform.value);

    if(this.registerform.valid)
    {
      alert("Thank You for Details. Can see the details in console");
    }
  }


  get firstname(){ return this.registerform.get('firstname'); }  //firstname
  get lastname(){ return this.registerform.get('lastname'); }  //lastname
  get email(){ return this.registerform.get('email'); }  //email Id
  get mobileNumber(){ return this.registerform.get('mobileNumber'); }  //email Id
  get address(){ return this.registerform.get('address'); }   // address
  get date(){ return this.registerform.get('date'); }   // address
}
