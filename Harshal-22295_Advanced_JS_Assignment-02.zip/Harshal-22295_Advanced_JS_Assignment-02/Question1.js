const fetch=require('node-fetch')



var url1="https://raw.githubusercontent.com/prust/wikipedia-movie-data/master/movies.json"

async function data1(){
    const response= await fetch(url1);
    return response.json();
}

data1()
.then(jsonData=>{
    //console.log(jsonData)

    //Varialble for Storing required data
    var actors=[]
    var genres=[]
    var final=[]
    //Traversing the whole JSON data
    jsonData.forEach(element => {
        //console.log(element.cast)
        //console.log(element.genres)
       element.cast.forEach(element_actor=>{
           //Storing actor name as key and its movies as value array
           if(actors[element_actor]==undefined){
            actors[element_actor]=[]
            actors[element_actor].push(element.title)
           }
           else{
            actors[element_actor].push(element.title)
            //actors[element_actor].push(element.title);
           }
       });

       element.genres.forEach(element_genre=>{
           //Storing genre type as key and its movies as value array
        if(genres[element_genre]==undefined){
            genres[element_genre]=[]
            genres[element_genre].push(element.title)
           }
           else{
            genres[element_genre].push(element.title)
           // console.log(genres[element_genre]);
            //genres[element_genre].push(element.title);
           }
      });
        
    });

    ///DEBUGGING
       //console.log(actors);
       //console.log(genres);
      

    //Formatting the output
    final["actors"]=actors;
    final["genres"]=genres;
    console.log(final);
})
