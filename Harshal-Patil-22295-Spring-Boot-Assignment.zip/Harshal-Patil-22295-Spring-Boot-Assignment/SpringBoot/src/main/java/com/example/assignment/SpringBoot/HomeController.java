package com.example.assignment.SpringBoot;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
	
	@RequestMapping("/details")
    public String sayHello() {
		
       System.out.println("In Home Controller...");
	return "Harshal patil: "+ "Q-22295. "+"Welcome to Q";
    }

}
