const express = require('express')
const path = require('path')
const bodyParser =require('body-parser')
const mongoose =require ('mongoose')
const bcrypt = require('bcryptjs')
const fs = require('fs')
const fetch=require('node-fetch')
const { ReturnDocument } = require('mongodb')

//SHOULD BE CONFENDENTIAL
const JWT_SECRET='wczxcadsnciubiuwiudjqwojs0oiefcoi1231324242!!!@@@@#!@$2sdjnvsjnvasdnvonvrnnodsvnownv'



const app= express()
app.use('/', express.static(path.join(__dirname, 'static')))
app.use(bodyParser.json())



////Search Api
app.post('/api/Question2', async (request,response) =>{
    const{data} =request.body
    try{

        var url_main="https://api.github.com/search/repositories?q={{input data}}"
        
        async function data_main(){
            const response= await fetch(url_main);
            return response.json();
        }

        var finalResult=[]
        data_main()
        .then(jsonData=>{
            
            var dataValues=[];
           
            jsonData.items.forEach(element => {
                var dataValues=[];
                dataValues["names"]=element.name;
                dataValues["fullnames"]=element.full_name;
                dataValues["private"]=element.private;
                if(element.license!=null){
                    dataValues["licenseName"]=element.license.name;
                }
                else{
                    dataValues["licenseName"]=element.license;
                }
                dataValues["score"]=element.score;

                url_numberOfBranch=element.branches_url;
                url_numberOfBranch=url_numberOfBranch.slice(0,url_numberOfBranch.lastIndexOf('/')-1)
               // console.log(url_numberOfBranch)
                async function data_numberOfBranch(){
                    const response= await fetch(url_numberOfBranch);
                    return response.json();
                }
                data_numberOfBranch()
                .then(jsonData2=>{
                    dataValues["numberOfBranch"]=Object.keys(jsonData2).length
                  //  console.log(jsonData2)
                });
               
                dataValues["Ownerlogin"]=element.owner.login;

                url_ownerName=element.owner.url;
                async function data_ownerName(){
                    const response= await fetch(url_ownerName);
                    return response.json();
                }
                data_ownerName()
                .then(jsonData3=>{
                    dataValues["OwnerName"]=jsonData3.login
                });

                url_ownerFollwer=element.owner.followers_url;
                async function data_ownerFollwer(){
                    const response= await fetch(url_ownerFollwer);
                    return response.json();
                }
                data_ownerFollwer()
                .then(jsonData4=>{
                    dataValues["OwnerfollowersCount"]=Object.keys(jsonData4).length
                });

                url_ownerFollwing=element.owner.following_url;
                url_ownerFollwing=url_ownerFollwing.slice(0,url_ownerFollwing.lastIndexOf('{')-1)
                async function data_ownerFollwing(){
                    const response= await fetch(url_ownerFollwing);
                    return response.json();
                }
                data_ownerFollwing()
                .then(jsonData5=>{
                    dataValues["OwnerfollowingCount"]=Object.keys(jsonData5).length
                });
                finalResult.push(dataValues)

            });
            console.log(finalResult)
            response.json({data:finalResult})
        });

    }catch(error){
       // console.log("I caught")
        response.json({status:'error',error:' Something went Wrong'})
    }
})

app.listen(9000, function(request,response) {
    console.log("Running...")
})