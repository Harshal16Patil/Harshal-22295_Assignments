const fetch=require('node-fetch')



var url1="http://api.nobelprize.org/v1/prize.json"

async function data1(){
    const response= await fetch(url1);
    return response.json();
}

data1()
.then(jsonData=>{
    //console.log(jsonData)
    var namesOfChemistry=[] //Names for chemistry category in given range
    var entriesWithnRange=[] //all data fetch within given range
    let prizes=Object.values(jsonData)
    prizes[0].forEach(element => {
        if(element.year>=2000&&element.year<=2019)
        {
            // fecthing all entry data within given range
            entriesWithnRange.push(element)
            if(element.category=="chemistry"){
                //fecthing only chemistry names in given range
                //console.log(element.laureates[0].firstname)
                namesOfChemistry.push(element.laureates[0].firstname+" "+element.laureates[0].surname)
            }
        }
    });
    console.log(entriesWithnRange);
    console.log(namesOfChemistry);

})
