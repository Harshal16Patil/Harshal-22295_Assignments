const express = require('express')
const path = require('path')
const bodyParser =require('body-parser')
const mongoose =require ('mongoose')
const User= require('./model/user')
const bcrypt = require('bcryptjs')
const fs = require('fs')
const  jwt =require('jsonwebtoken')
const { ReturnDocument } = require('mongodb')
var databaseArray=[]


//////DATABASE TRIAL

/*mongoose.connect('mongodb://localhost:9000/login-app-db',{
    useNewUrlParser:true,
    useUnifiedTopology:true,
    
})
*/

//SHOULD BE CONFENDENTIAL
const JWT_SECRET='wczxcadsnciubiuwiudjqwojs0oiefcoi1231324242!!!@@@@#!@$2sdjnvsjnvasdnvonvrnnodsvnownv'



const app= express()
app.use('/', express.static(path.join(__dirname, 'static')))
app.use(bodyParser.json())



////VIEW OTHER USERS INFO API
app.post('/api/showotherusersinfo', async (request,response) =>{
    const{ viewusername,username} =request.body
    try{
        for(var i=0;i<databaseArray.length;i++)
        {
           // console.log(i)
            if(databaseArray[i].username==username)
            {
                break;
            }
        }
        if(i==databaseArray.length)
        {
            response.json({status:'error', error:'Invalid Username'})
        }
        else{
            for(var j=0;j<databaseArray.length;j++)
            {
                //console.log(i)
                if(databaseArray[j].username==viewusername)
                {
                    break;
                }
            }
            if(j==databaseArray.length)
            {
                response.json({status:'error', error:'Invalid ViewUsername'})
            }
            else{
                console.log(databaseArray[j].username)
                console.log(databaseArray[j].email)
                console.log(databaseArray[j].number)
                
                response.json({status:'ok',data:databaseArray[j].username + " " + databaseArray[j].email+ " "+databaseArray[j].number})
            }
            
            
        }
    }catch(error){
       // console.log("I caught")
        response.json({status:'error',error:' Invalid Username'})
    }
})




/////CHANGE USERS INFO API
app.put('/api/changeuserinfo', async (request,response) =>{
    const{ oldusername, newemail,newusername,newnumber} =request.body
    try{
        for(var j=0;j<databaseArray.length;j++)
        {
            if(databaseArray[j].username==newusername)
            {
                return response.json({ status:'error', error:'Username already exits'})
            }
        }
        for(var i=0;i<databaseArray.length;i++)
        {
            //console.log(i)
            if(databaseArray[i].username==oldusername)
            {
                break;
            }
        }
        if(i==databaseArray.length)
        {
            response.json({status:'error', error:'Invalid OldUsername'})
        }
        else{
            if(!newusername||typeof newusername!=='string'){
                return response.json({ status:'error', error:'Invalid NewUsername'})
            }
            if(!newnumber||newnumber.length!==10){
                return response.json({ status:'error', error:'Invalid mobile number'})
            }
            databaseArray[i].username=newusername
            databaseArray[i].email=newemail
            databaseArray[i].number=newnumber
            response.json({status:'ok'})
            
        }
    }catch(error){
        console.log("I caught")
        response.json({status:'error',error:'Invalid OldUsername'})
    }
})










/////CHANGE-PASSWORD API
app.put('/api/changepassword', async (request,response) =>{
    const{ newpassword:plainTextnewPassword,username} =request.body
    try{
        for(var i=0;i<databaseArray.length;i++)
        {
            console.log(i)
            if(databaseArray[i].username==username)
            {
                break;
            }
        }
        if(i==databaseArray.length)
        {
            response.json({status:'error', error:'Invalid Username'})
        }
        else{
            if(!plainTextnewPassword||typeof plainTextnewPassword!=='string'){
                return response.json({ status:'error', error:'Invalid password'})
            }
            if(plainTextnewPassword.length<6){
                return response.json({ status:'error', error:'Password too small. Sholud be atleast 6 characters'})
            }
            //Hashing  new password
        
            const newpassword = await bcrypt.hash(plainTextnewPassword,10)
            databaseArray[i].password=newpassword
            response.json({status:'ok'})
            
        }
    }catch(error){
        //console.log("I caught")
        response.json({status:'error',error:'Invalid Username'})
    }
})

////LOGIN API
app.post('/api/login', async(request, response)=> {
    const{username,password}= request.body
    //console.log(i)
    //console.log(databaseArray.length)
    for(var i=0;i<databaseArray.length;i++)
    {
        console.log(i)
        if(databaseArray[i].username==username)
        {
            break;
        }
    }
    if(i==databaseArray.length)
    {
        response.json({status:'error', error:'Invalid Username/Password'})
    }
    else{
        if(await bcrypt.compare(password,databaseArray[i].password)){
            const token =jwt.sign({
                id:i,
                username: databaseArray[i].username
                
            },
            JWT_SECRET
        )
            response.json({status:'ok', data:token})
            
        }
        else{

        }
        response.json({status:'error', error:'Invalid Username/Password'})
    }
   
})

////REGISTRATION API
app.post('/api/register', async (request, response)=>{
    //console.log(request.body)
    
    const{username,password :plainTextPassword ,email,number}= request.body
    //Checking for username already exits or not
    for(var i=0;i<databaseArray.length;i++)
    {
        if(databaseArray[i].username==username)
        {
            return response.json({ status:'error', error:'Username already exits'})
        }
    }
    if(!username||typeof username!=='string'){
        return response.json({ status:'error', error:'Invalid Username'})
    }
    if(!plainTextPassword||typeof plainTextPassword!=='string'){
        return response.json({ status:'error', error:'Invalid password'})
    }
    if(plainTextPassword.length<6){
        return response.json({ status:'error', error:'Password too small. Sholud be atleast 6 characters'})
    }
    if(!number||number.length!==10){
        return response.json({ status:'error', error:'Invalid mobile number'})
    }
    //Hashing  using 10 as salt
    const password = await bcrypt.hash(plainTextPassword,10)

    ////////TRYING ARRAY METHOD
    databaseArray.push({username,password ,email,number})
    //console.log(databaseArray)



    /////////TRYING JSON_FILE METHOD

   /* fs.readFile("./databaseFile.json","utf8",(err,jsonString) => {
        if(err){
            console.log("Error in reading file from disk:",err)
            return;
        }
        try {
            
            console.log(databaseArray)
            var ob= JSON.parse(jsonString)
           // console.log(typeof(ob))
           // console.log(ob)
            var a=[];
            a.push(ob)
                a.push({username,password ,email,number})
                console.log(a.length)
                fs.writeFile('./databaseFile.json',JSON.stringify(a,null,2),err=>{
                    if(err)
                    {
                        console.log(err)
                    } else{
                        console.log(' User Created Succesfully')
                    }
                })
            
        }catch(err){
            console.log("Error parsing JSON string:",err)
        }
    })
    */

    /////////TRYING DATABASE METHOD
    //console.log(password)
  /* try{ 
       await User.create({
           username,password,email,number
        })
        
        
    } catch(error){
        console.log("I am in catch")
        console.log(error)
        return response.json({status:'error'})
    }*/
    response.json({status: 'ok'})
})

app.listen(9000, function(request,response) {
    console.log("Running...")
})




